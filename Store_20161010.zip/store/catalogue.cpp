#include "catalogue.h"

#include <QAction>
#include <QMenu>

#include <QtSql>
#include <QtDebug>

#include "posaction.h"

#define DATA_PTR(D, I, VALUE)                                \
        Item::Data* D = (Item::Data*) (I.internalPointer()); \
        if ( ! D ) return VALUE

#define DATE_STR(DATE) ( \
     DATE.isValid() ? DATE.toString("dd.MM.yyyy") : QString() \
)

namespace STORE {
namespace Catalogue {

/*********************************************************************/

Model::Model( QObject *parent)
    : QAbstractItemModel ( parent ) {

    LastTempId( 1 ) ;

    QSqlQuery qry;
    qry.setForwardOnly( true ) ;
    qry.prepare(
           "select            \n"
           "iid,              \n"
           "code,             \n"
           "title,            \n"
           "valid_from,       \n"
           "valid_to,         \n"
           "islocal,          \n"
           "acomment,         \n"
           "rid_parent,       \n"
           "alevel            \n"
           "from catalogue    \n"
           "order by alevel ; \n"
     ) ;

    if ( qry.exec() ) {
       while ( qry.next() ) {
           int ParentId = qry.value("rid_parent").toInt() ;
           Item::Data *P = Cat.findPointer( ParentId ) ;
           if ( P ) {
               Item::Data *D = new Item::Data( P, qry ) ;
               P->Children.append(D);
               D->pParentItem = P ;
           } else {
               Item::Data *D = new Item::Data( this, qry ) ;
               Cat.append( D );
               D->pParentItem = 0 ;
           }
       }
    } else {
       qCritical() << "Cannot execute query" ;
       QSqlError Err = qry.lastError() ;
       qCritical() << Err.nativeErrorCode() ;
       qCritical() << Err.databaseText().toUtf8().data() ;
       qCritical() << Err.driverText().toUtf8().data()  ;
       //qDebug() << qry.executedQuery() ;
    }

    /*
     //TODO Это тестовый каталог. Заменить на настоящий
     Item::Data *D = new Item::Data( this );
     D->Code  = "111";
     D->Title = "Физика" ;
     D->From  = QDateTime::currentDateTime() ;
     D->To    = QDateTime() ;
     D->IsLocal = false ;
     Cat.append( D );
    }
    {
     Item::Data *D = new Item::Data( this );
     D->Code  = "222" ;
     D->Title = "Математика" ;
     D->From  = QDateTime::currentDateTime() ;
     D->To    = QDateTime() ;
     D->IsLocal = false ;
     Cat.append( D );
    }
    {
     Item::Data *D = new Item::Data( this );
     D->Code  = "333" ;
     D->Title = "Биология" ;
     D->From  = QDateTime::currentDateTime() ;
     D->To    = QDateTime() ;
     D->IsLocal = false ;
     Cat.append( D );
    }
    {
     Item::Data *D = new Item::Data( this );
     D->Code  = "444" ;
     D->Title = "Валеология" ;
     D->From  = QDateTime::currentDateTime() ;
     D->To    = QDateTime() ;
     D->IsLocal = true ;
     Cat.append( D );
    }
    {
     Item::Data *D = new Item::Data( this );
     D->Code  = "555";
     D->Title = "Литература" ;
     D->From  = QDateTime::currentDateTime() ;
     D->To    = QDateTime() ;
     D->IsLocal = false ;
     D->Comment = "Комментарий" ;
     Cat.append( D );
    }
    */

}

/*--------------------------------------------------------------------*/

Model::~Model() {
}

/*--------------------------------------------------------------------*/

int Model::rowCount( const QModelIndex & parent ) const {
    if ( ! parent.isValid() ) {
        return Cat.size() ; // TODO Заменить на правильное кол-во
    } else {
        //Item::Data* P = (Item::Data*) parent.internalPointer() ;
        //id ( ! P ) return 0 ;
        DATA_PTR(P, parent, 0) ;
        return P->Children.size()  ;
    }
}

/*--------------------------------------------------------------------*/

int Model::columnCount( const QModelIndex &parent ) const {
   return 6 ;
}

/*--------------------------------------------------------------------*/
QVariant Model::dataDisplay( const QModelIndex &I ) const {
    //Item::Data *D = Cat[I.row()] ;
    DATA_PTR( D, I, QVariant() ) ;

    switch( I.column() ) {
    case 0 : return D->Code ;
    case 1 : return D->Title ;
    case 2 : return /*D->From.isValid() ? D->From.toString("dd.MM.yyyy") : ""; */
                     DATE_STR(D->From) ;
    case 3 : return /*D->To.isValid()   ? D->To.toString("dd.MM.yyyy")   : "" ;*/
                     DATE_STR(D->To) ;
    case 4 : return D->IsLocal ? tr ("LOCAL") : QString() ;
    case 5 : return D->Comment.isEmpty() ? QString() : tr( "CMT" ) ;
    default: return QVariant() ;
    }

}

QVariant Model::dataTextAlignment( const QModelIndex &I ) const {
    int Result  = Qt::AlignVCenter ;
    Result |= ( I.column() == 1 ) ? Qt::AlignLeft : Qt::AlignHCenter ;
    return Result ;
}

/*
Item::Data *Model::dataDataPointer( const QModelIndex &I ) const {
    int R = I.row() ;
    if ( R < 0 || R >= Cat.size() ) return 0 ;
    return Cat[R] ;
}
*/

QVariant Model::dataFont( const QModelIndex &I ) const {
    //Item::Data *D = dataDataPointer( I ) ;
    DATA_PTR( D, I, QVariant() ) ;
    QFont F ;
    if ( D->Deleted ) F.setStrikeOut( true );
    return F;
}

QVariant Model::dataForeground( const QModelIndex &I ) const {
    //Item::Data *D = dataDataPointer( I ) ;
    DATA_PTR( D, I, QVariant() ) ;
    if ( ! D ) return QVariant() ;
    QColor Result = D->IsLocal ? QColor( "blue" ) :  QColor( "black" ) ;
    if ( ! D->isActive() ) Result.setAlphaF( 1.0/3.0 );
    return Result;
}

QVariant Model::dataToolTip( const QModelIndex &I ) const {
    //Item::Data *D = dataDataPointer( I ) ;
    DATA_PTR( D, I, QVariant() ) ;
    if ( ! D ) return QVariant() ;

    switch ( I.column() ) {
    case 2: {
        if ( !D->To.isValid() || D->To.isNull() ) return QVariant() ;
        return tr("Valid to: %1").arg(D->To.toString("dd.MM.yyyy")) ;
    }
    default: return QVariant() ;
    }
}

QVariant Model::data( const QModelIndex &I, int role ) const {

   switch ( role ){
   case Qt::DisplayRole          : return dataDisplay( I ) ;
   case Qt::TextAlignmentRole    : return dataTextAlignment( I ) ;
   case Qt::ForegroundRole       : return dataForeground( I ) ;
   case Qt::FontRole             : return dataFont( I ) ;
   case Qt::ToolTipRole          : return dataToolTip( I ) ;
   case Qt::UserRole+1           : {
       //Item::Data *D = dataDataPointer(I) ;
       //if ( ! D ) return false ;
       DATA_PTR( D, I, false ) ;
       return D->Deleted ;
       }
   default : return QVariant() ;
   }
}

/*--------------------------------------------------------------------*/

QVariant Model::headerData(int section,
                    Qt::Orientation orientation, int role) const {

    if ( orientation != Qt::Horizontal )
        return QAbstractItemModel::headerData(section, orientation, role);

    switch ( role ) {

    case Qt::DisplayRole :
         switch ( section ) {
         case 0 : return tr("Code")  ;
         case 1 : return tr("Title") ;
         case 2 : return tr("From")  ;
         case 3 : return tr("To")    ;
         case 4 : return tr("Local") ;
         default : return QVariant()  ;
    }

    case Qt::TextAlignmentRole :
         return QVariant( Qt::AlignBaseline | Qt::AlignHCenter ) ;

    case Qt::ForegroundRole :
        {   // TODO Сделать шрифт жирным
            QFont F ;
            F.setBold( true );
            return F ;
        }

    default: return QVariant() ;
    }

}

/*-------------------------------------------------------------------*/
void Model::editItem( const QModelIndex &I, QWidget *parent ) {

    //Item::Data *D = dataDataPointer(I) ;

    //Item::Data *D = (Item::Data*)I.internalPointer() ;
    //if ( ! D ) return ;
    DATA_PTR( D, I, ) ;

    Item::Dialog Dia( parent ) ;

    Dia.setDataBlock( D );
    beginResetModel();
    Dia.exec() ;
    endResetModel();
}

/*-------------------------------------------------------------------*/

void Model::newItem( const QModelIndex &parentI, QWidget *parent ) {
   if ( parentI.isValid() ) {
      // TODO Сделать добавление нового элемента необязательно в корень каталога
      qWarning() << "Cannot add non-toplevel item" ;
      return ;
   }
   Item::Data *D = new Item::Data( this ) ;
   if ( !D ) {
      qWarning() << "Cannot create new item" ;
      return ;
   }
   Item::Dialog Dia( parent ) ;
   Dia.setDataBlock( D );
   if ( Dia.exec() == QDialog::Accepted ) {
       beginResetModel();
       Cat.append( D );
       D->setProperty( "temp_id", tempId() ) ;
       endResetModel();
   } else {
       delete D ;
   }

}

/*-------------------------------------------------------------------*/

QModelIndex Model::index( int row, int column,
                                  const QModelIndex& parent ) const  {
    if ( parent.isValid() ) {
       DATA_PTR( D, parent, QModelIndex() ) ;
       return createIndex( row, column, (void*)D ) ;
    } else {
       if ( row < 0 || row >= Cat.size() ) return QModelIndex() ;
       return createIndex( row, column, (void*)(Cat[row]) ) ;
    }
}

/*-------------------------------------------------------------------*/
QModelIndex Model::parent( const QModelIndex &I ) const {
    DATA_PTR( D, I, QModelIndex() ) ;
    Item::Data *P = D->pParentItem ;
    if ( !P ) {
       return QModelIndex() ;
    } else {
        int Row = -1 ;
        Item::Data *GP = P->pParentItem ;
        if ( GP ) {
            for ( int i = 0; i < GP->Children.size() ; i++ ) {
                if ( GP->Children[i]->isSameAs(P) ){
                    Row = i ;
                    break ;
                }
            }
        } else {
            for ( int i = 0; i < Cat.size() ; i++ ) {
                if ( Cat[i]->isSameAs(P) ){
                    Row = i ;
                    break ;
                }
            }
        }
        if ( Row < 0 ) {
            qWarning()<< "Cannot find item " ;
            return QModelIndex() ;
        }
        return create_index( Row, 0, P ) ;
    }
}

/*-------------------------------------------------------------------*/
void Model::delItem( const QModelIndex &I, QWidget *parent ) {
    // TODO Спросить у пользователя, уверен ли он, что хочет удалить элемент

    // Item::Data *D = dataDataPointer(I) ;
    // if ( ! D ) return ;
    DATA_PTR( D, I, ) ;

    //TODO Исходим из того, что модель линейна
    beginResetModel() ;

    if ( D->isNew() ) {
       Item::Data *P = D->pParentItem ;
       if ( P ) {
           P->Children.removeAt( I.row() );
       } else {
           Cat.removeAt( I.row() ) ;
       }
       delete D;
    } else {
       D->Deleted = ! (D->Deleted) ;
    }

    endResetModel() ;
}
/*********************************************************************/

TableView::TableView( QWidget *parent)
    : QTableView( parent ) {

     setContextMenuPolicy( Qt::CustomContextMenu ) ;

     connect( this, SIGNAL(customContextMenuRequested(QPoint)),
              this, SLOT(contextMenuRequested(QPoint)) );

     Model *M = new Model( this ) ;
     setModel( M ) ;

     {
      PosAction *A = actEditItem = new PosAction( this ) ;
      A->setText( tr("Edit") );
      connect( A, SIGNAL(editItem(QModelIndex,QWidget*)),
               M, SLOT(editItem(QModelIndex,QWidget*)) );
      addAction(A) ;
     }

     {
      PosAction *A = actNewItem = new PosAction( this ) ;
      A->setText( tr("Add") );
      connect( A, SIGNAL(editItem(QModelIndex,QWidget*)),
               M, SLOT(newItem(QModelIndex,QWidget*)) );
      addAction(A) ;
     }

     {
      PosAction *A = actDelItem = new PosAction( this ) ;
      A->setText( tr("Delete") );
      connect( A, SIGNAL(editItem(QModelIndex,QWidget*)),
               M, SLOT(delItem(QModelIndex,QWidget*)) );
      addAction(A) ;
     }

     {
      QHeaderView *H = verticalHeader();
      H->setSectionResizeMode(QHeaderView::ResizeToContents) ;
     }
     {
      QHeaderView *H = horizontalHeader();
      H->setSectionResizeMode(QHeaderView::ResizeToContents) ;
      H->setSectionResizeMode( 1, QHeaderView::Stretch );
     }

     setColumnHidden( 3, true ) ;
     setColumnHidden( 4, true ) ;
}

/*-------------------------------------------------------------------*/

TableView::~TableView() {
}

/*-------------------------------------------------------------------*/

/*
void TableView::editItem() {

}
*/

/*-------------------------------------------------------------------*/

void TableView::contextMenuRequested( const QPoint &p ) {
     QMenu M(this) ;
     QModelIndex I = indexAt(p) ;
     if ( I.isValid() ) {
        actEditItem->I = I ;
        actEditItem->pWidget = this ;
        M.addAction( actEditItem ) ;
        //
        actDelItem->I = I;
        actDelItem->pWidget = this ;

        if ( I.data( Qt::UserRole+1 ).toBool() ) {
           actDelItem->setText( tr("Restore") );
        } else {
           actDelItem->setText( tr("Delete") );
        }

        M.addAction( actDelItem ) ;
     }
     actNewItem->I = QModelIndex() ;
     actNewItem->pWidget = this ;
     M.addAction( actNewItem ) ;
     //--
     M.exec( mapToGlobal(p) ) ;
}

/*********************************************************************/

} // namespace Catalogue
} // namespace STORE



